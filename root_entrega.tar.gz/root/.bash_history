history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ping -c 4 google.com
nano /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
dhclient -v
ping -c 3 google.com
apt update
vi /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworn main contrib non-free non-free non-free-firmware" >/etc/apt/sources.list
apt update
echo "deb http://deb.debian.org/debian/ bookworm main contrib non-free non-free-firmware" > /etc/apt/sources.list
apt update
apt full-upgrade -y
reboot
cat /etc/debian_version
poweroff
ls -la /root/.ssh
ls -lh /root
tar -zxvf /root/Material_Adicional_TPVMCA.tar.gz -C /root/
bash
mv /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
mv /root/Material_Adicional_TPVMCA/clave_privada.txt /root/.ssh/id_rsa
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
chmod 600 /root/.ssh/id_rsa
nano /etc/ssh/sshd_config
apt install nano -y
nano /etc/ssh/sshd_config
ls clear
clear
ls -l /etc/ssh/sshd_config
apt install openssh-server -y
nano /etc/ssh/sshd_config
clear
system restart ssh
systemctl restart ssh
cat /root/.ssh/id_rsa
cat /root/.ssh/id_rsa
exit
cat /root/.ssh/id_rsa
restart
systemctl restart
power off
poweroff
cat /root/.ssh/id_rsa
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEA6JtIDt0a9gdiFJcqdx4BjKIWczRX18YLoGHFK6V43AkBxCf8Wb5m
NOTGRReXDd310w2GnVjQ7SAtyKQh2A/XUt0Qla487Wsh+QrHROaASJq1XmvOW2LKWXypTW
f99vK+LkIf/Pi3KaqRg705Y9n/Bp5z4QAUKuZcKFWdOA/WTrG8AUDN8FYPTzjGaPFl47T6
WL1cX0G+kWTQWaGNexFBe961pZut0M+pCObausjMmcmqmRq+xuMfsgFezf2Fsapjc/nxOA
ML90Dch+sYSiJEU52oxFuvGnkLhV/qGNCgUg4cr2HlGb5ItrO41VjV8TLtO8WEL+xu1Si9
eDfU5d7dItdbbGpYclsQbKcs0kJo4EAqzsbwoDVG7Gj+f8BwE7cuuEEByy/q6Dx8bXbP5y
XJ8BzuXxptxOoiBuLdzg1K1n3fhZC5pRIc5PPnJvFNRvcefLvzVx+ISNuuJ1kdJOpa5wH0
ls5T9/Ad/bhYK4y6s5YwPB5gFDgcWCyB5lOp5305AAAFmCA1FSIgNRUiAAAAB3NzaC1yc2
EAAAGBAOibSA7dGvYHYhSXKnceAYyiFnM0V9fGC6BhxSuleNwJAcQn/Fm+ZjTkxkUXlw3d
9dMNhp1Y0O0gLcikIdgP11LdEJWuPO1rIfkKx0TmgEiatV5rzltiyll8qU1n/fbyvi5CH/
z4tymqkYO9OWPZ/waec+EAFCrmXChVnTgP1k6xvAFAzfBWD084xmjxZeO0+li9XF9BvpFk
0FmhjXsRQXvetaWbrdDPqQjm2rrIzJnJqpkavsbjH7IBXs39hbGqY3P58TgDC/dA3IfrGE
oiRFOdqMRbrxp5C4Vf6hjQoFIOHK9h5Rm+SLazuNVY1fEy7TvFhC/sbtUovXg31OXe3SLX
W2xqWHJbEGynLNJCaOBAKs7G8KA1Ruxo/n/AcBO3LrhBAcsv6ug8fG12z+clyfAc7l8abc
TqIgbi3c4NStZ934WQuaUSHOTz5ybxTUb3Hny781cfiEjbridZHSTqWucB9JbOU/fwHf24
WCuMurOWMDweYBQ4HFgsgeZTqed9OQAAAAMBAAEAAAGASYpOjeR50a8j4z6nvmFOPBhC4M
l7vExxAJPospPuUiLG3C2IKxd3WOG7jbyXlVrHjaKJHNYnt9CkqPq7eIQJn7kktS4RNT7Z
ztMJjU8S3+GJ1gBfjaT+NKylGkP2l0zHs/hUBLbdsd6rgusgaeFSL9WI7WoI9kc+e8IVot
Pe/aJTvlGuyn1q+bEJicRIYmWlgMjdm4A9r9ofxTa+dFpQSclvxJwjqBD/cEEMhmFVzolj
1mQOTPMh4jVss9OjoTgs/tVFvPSXJWWw1lRyyDSKyMpbMUzceavAHWYKuS0tGBN94Mz2Xb
nN6MrDojUcPa4J61sJD+nAYAl6J/8vQ1MCy/tGRCiMkwt+UxZUh6wgulZyege4eggyRP3u
mwzawhrWK3Yhnfq/st3HmiH4YAdudfDIvACl10jpDuC08Vo/Q25Aqbq1xmyxcBASZg39fb
COArvkTYSoqs67bRG+OnRD/O/aFtX7LT2mpVJEuVl+R5iJ9/1Lxw7qdWciN6evAZzBAAAA
wQC7vYM9lgGs1UCwaniqS595vGsbPBaVl1J8RUfyoSleC2Fo2kNWOXKQ43gMAkXOoNyKeR
T+ju/G5unKkxZmi0euNB9W3dDL+mkd1/hu63nA+7i5SnyhlGeJHfRAEt+3fYkFftTWKRSn
fO8+povmzvI2N4sike6zcQG0jw7SVcI6BzRstUnF0VKxnuhF4RfzgORWrrKw+pFxamN8DI
Vj4nEUjtc7xjqJ0TkM9ajVvu8fg2SFD2qU9Y8nTZsY/vR4KwQAAADBAP+5EZh/7U9talmN
yi4rW3kVU8mgg4qCG/36HecLn4XI9xyOoNTYRcDttqAUOkUWIyZcxNnDgw58MydzUopPjE
3UFMZOZgFtTXWGxA6fEv+yu3m3wt42+3D25ULRwlGqFvDdTAzgRug1hZttN72isfT5Sm7j
W7BCIf+3xGhiX9TQ4RMqjI2v2//7CIHLMZu1JdKLYOmuaM9qEGKgbtmzYyDg5xN2vIpymB
Q8K4hnrnBbqyfmBhhpGTKBIwyoyRaanwAAAMEA6NvNA2mRYt+gF8NlFPSAHUk4w6z25drw
/1C+KyX8+iAbPa/9kGlTx83DLzq+O4DrxXvePNJVBTfH+XlMwSQYgTgHmEk1HWgcVfUFv9
+5CMqO9KlXP+jLBdJTcZJ8jDZOdZgh0094vKX4Td3gGB5LNqa4iYBjbaETszrd3nZTnBjg
5LeguNxTHxKJw2O90p7vh94/rflAGUc8Kir/++mxYkBly37n2FP2KNTPYoY2wEcm+aQK20
GmYVmiE9ycsrEnAAAAHHNvbmRhQHR0eXM5LUhQLUVOVlktTm90ZWJvb2sBAgMEBQY=
-----END OPENSSH PRIVATE KEY-----
cat /root/.ssh/id_rsa
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEA6JtIDt0a9gdiFJcqdx4BjKIWczRX18YLoGHFK6V43AkBxCf8Wb5m
NOTGRReXDd310w2GnVjQ7SAtyKQh2A/XUt0Qla487Wsh+QrHROaASJq1XmvOW2LKWXypTW
f99vK+LkIf/Pi3KaqRg705Y9n/Bp5z4QAUKuZcKFWdOA/WTrG8AUDN8FYPTzjGaPFl47T6
WL1cX0G+kWTQWaGNexFBe961pZut0M+pCObausjMmcmqmRq+xuMfsgFezf2Fsapjc/nxOA
ML90Dch+sYSiJEU52oxFuvGnkLhV/qGNCgUg4cr2HlGb5ItrO41VjV8TLtO8WEL+xu1Si9
eDfU5d7dItdbbGpYclsQbKcs0kJo4EAqzsbwoDVG7Gj+f8BwE7cuuEEByy/q6Dx8bXbP5y
XJ8BzuXxptxOoiBuLdzg1K1n3fhZC5pRIc5PPnJvFNRvcefLvzVx+ISNuuJ1kdJOpa5wH0
ls5T9/Ad/bhYK4y6s5YwPB5gFDgcWCyB5lOp5305AAAFmCA1FSIgNRUiAAAAB3NzaC1yc2
EAAAGBAOibSA7dGvYHYhSXKnceAYyiFnM0V9fGC6BhxSuleNwJAcQn/Fm+ZjTkxkUXlw3d
9dMNhp1Y0O0gLcikIdgP11LdEJWuPO1rIfkKx0TmgEiatV5rzltiyll8qU1n/fbyvi5CH/
z4tymqkYO9OWPZ/waec+EAFCrmXChVnTgP1k6xvAFAzfBWD084xmjxZeO0+li9XF9BvpFk
0FmhjXsRQXvetaWbrdDPqQjm2rrIzJnJqpkavsbjH7IBXs39hbGqY3P58TgDC/dA3IfrGE
oiRFOdqMRbrxp5C4Vf6hjQoFIOHK9h5Rm+SLazuNVY1fEy7TvFhC/sbtUovXg31OXe3SLX
W2xqWHJbEGynLNJCaOBAKs7G8KA1Ruxo/n/AcBO3LrhBAcsv6ug8fG12z+clyfAc7l8abc
TqIgbi3c4NStZ934WQuaUSHOTz5ybxTUb3Hny781cfiEjbridZHSTqWucB9JbOU/fwHf24
WCuMurOWMDweYBQ4HFgsgeZTqed9OQAAAAMBAAEAAAGASYpOjeR50a8j4z6nvmFOPBhC4M
l7vExxAJPospPuUiLG3C2IKxd3WOG7jbyXlVrHjaKJHNYnt9CkqPq7eIQJn7kktS4RNT7Z
ztMJjU8S3+GJ1gBfjaT+NKylGkP2l0zHs/hUBLbdsd6rgusgaeFSL9WI7WoI9kc+e8IVot
Pe/aJTvlGuyn1q+bEJicRIYmWlgMjdm4A9r9ofxTa+dFpQSclvxJwjqBD/cEEMhmFVzolj
1mQOTPMh4jVss9OjoTgs/tVFvPSXJWWw1lRyyDSKyMpbMUzceavAHWYKuS0tGBN94Mz2Xb
nN6MrDojUcPa4J61sJD+nAYAl6J/8vQ1MCy/tGRCiMkwt+UxZUh6wgulZyege4eggyRP3u
mwzawhrWK3Yhnfq/st3HmiH4YAdudfDIvACl10jpDuC08Vo/Q25Aqbq1xmyxcBASZg39fb
COArvkTYSoqs67bRG+OnRD/O/aFtX7LT2mpVJEuVl+R5iJ9/1Lxw7qdWciN6evAZzBAAAA
wQC7vYM9lgGs1UCwaniqS595vGsbPBaVl1J8RUfyoSleC2Fo2kNWOXKQ43gMAkXOoNyKeR
T+ju/G5unKkxZmi0euNB9W3dDL+mkd1/hu63nA+7i5SnyhlGeJHfRAEt+3fYkFftTWKRSn
fO8+povmzvI2N4sike6zcQG0jw7SVcI6BzRstUnF0VKxnuhF4RfzgORWrrKw+pFxamN8DI
Vj4nEUjtc7xjqJ0TkM9ajVvu8fg2SFD2qU9Y8nTZsY/vR4KwQAAADBAP+5EZh/7U9talmN
yi4rW3kVU8mgg4qCG/36HecLn4XI9xyOoNTYRcDttqAUOkUWIyZcxNnDgw58MydzUopPjE
3UFMZOZgFtTXWGxA6fEv+yu3m3wt42+3D25ULRwlGqFvDdTAzgRug1hZttN72isfT5Sm7j
W7BCIf+3xGhiX9TQ4RMqjI2v2//7CIHLMZu1JdKLYOmuaM9qEGKgbtmzYyDg5xN2vIpymB
Q8K4hnrnBbqyfmBhhpGTKBIwyoyRaanwAAAMEA6NvNA2mRYt+gF8NlFPSAHUk4w6z25drw
/1C+KyX8+iAbPa/9kGlTx83DLzq+O4DrxXvePNJVBTfH+XlMwSQYgTgHmEk1HWgcVfUFv9
+5CMqO9KlXP+jLBdJTcZJ8jDZOdZgh0094vKX4Td3gGB5LNqa4iYBjbaETszrd3nZTnBjg
5LeguNxTHxKJw2O90p7vh94/rflAGUc8Kir/++mxYkBly37n2FP2KNTPYoY2wEcm+aQK20
GmYVmiE9ycsrEnAAAAHHNvbmRhQHR0eXM5LUhQLUVOVlktTm90ZWJvb2sBAgMEBQY=
-----END OPENSSH PRIVATE KEY-----
cat /root/.ssh/id_rsa
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
chmod root:root /root/.ssh/authorized_keys
chown root:root /root/.ssh/authorized_keys
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
apt update
apt install apache2 php libapache2-mod-php mariadb-server php-mysql -y
restart
close
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
cat /root/Material_Adicional_TVMCA/clave_publica.pub > /root/.ssh/authorized_keys
cat /root/Material_Adicional_TPVMCA/clave_publica.pub > /root/.ssh/authorized_keys
find /root -name "clave_publica.pub"
ls -R /root
ls -r /root/.ssh
cd /root/.ssh
cat clave_publica.pub > authorized_keys
nano /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
systemctl restart ssh
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
systemctl restart ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
nano /root/.ssh/authorized_keys
chmod 600 /root/.shh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
systemctl restart ssh
apt install php libapache2-mod-php mariadb-server php-mysql -y
bash
mariadb
bash
mysql tp_base < /root/Material_Adicional_TPVMCA/db.sql
rm /var/html/index.html
rm /var/www/html/index.html
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
chown -R www-data:www-data /var/www/html/
cat /root/.ssh/id_rsa
sudo systemctl status ssh
cat /root/.ssh/id_rsa
curl -I http://localhost
ss -tuln | grep :80
POWER OFF
OFF
power off
poweroff
lsblk
fdisk /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdb1 /backup_dir
mount /dev/sdb2 /backup_dir
mount /dev/sdc2 /backup_dir
mount /dev/sdc1 /www.dir
mount /dev/sdc1 /www_dir
lsblk
umount /www_dir
umount /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
umount /dev/sdb1
cat /proc/partitions > /opt/particion
mv /var/www/html/index.php /www_dir/
mv /var/www/html/logo.png /www_dir/
chown -R www-data:www-data /www_dir/
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
nano /etc/fstab
reboot
