#!/bin/bash

# 5.5) Opción de ayuda (-help)
if [[ "$1" == "-help" ]]; then
    echo "========================================================="
    echo "            SCRIPT DE BACKUP - AYUDA"
    echo "========================================================="
    echo "Uso: $0 [directorio_origen] [directorio_destino]"
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "========================================================="
    exit 0
fi

ORIGEN=$1
DESTINO=$2

# 5.4) Validar que se pasen ambos argumentos (origen y destino)
if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo "Error: Faltan argumentos obligatorios."
    echo "Use '$0 -help' para ver la guía de uso."
    exit 1
fi

# 5.6) Validar que el sistema de archivos de origen exista
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

# 5.6) Validar que el destino esté montado como sistema de archivos
if ! mountpoint -q "$DESTINO"; then
    echo "Error: El directorio de destino '$DESTINO' no está montado o no está disponible."
    exit 1
fi

# 5.2) Configurar el formato de fecha ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Obtener el nombre limpio del directorio de origen (ej: de /var/log saca 'log')
NOMBRE_BASE=$(basename "$ORIGEN")

# Definir el nombre final del archivo comprimido
ARCHIVO_FINAL="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

# 5.3) Ejecutar el backup guardándolo en la partición de destino
echo "Iniciando compresión de $ORIGEN en $DESTINO/$ARCHIVO_FINAL..."
tar -czf "$DESTINO/$ARCHIVO_FINAL" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

# Verificar si el comando tar terminó con éxito
if [ $? -eq 0 ]; then
    echo "¡Backup completado con éxito con formato ANSI!"
    echo "Ubicación: $DESTINO/$ARCHIVO_FINAL"
else
    echo "Error crítico: Falló la creación del backup."
    exit 1
fi
